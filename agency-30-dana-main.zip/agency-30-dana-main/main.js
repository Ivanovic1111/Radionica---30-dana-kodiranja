$('.navbar-toggler').html("<i class='fas fa-bars fa-2x' style='color: var(--orange);'></i>");

$('.carousel').carousel({
    interval: 5000
})